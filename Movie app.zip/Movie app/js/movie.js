const APILINK = 'https://review-backend.beaucarnes.repl.co/api/v1/reviews/';
const url = new URL(location.href); //make url object from url
const movieId = url.searchParams.get("id");
const movieTitle = url.searchParams.get("title");


// creating html with js 
const main = document.getElementById("section");
const title = document.getElementById("title");
// const form = document.getElementById("form");
// const search = document.getElementById("query");


title.innerText = movieTitle;

retutnReviews(APILINK);


function retutnReviews(url){
  fetch(url + "movie/" + movieId).then(res => res.json())
  .then(function(data) {
    console.log(data);
    data.forEach( review => {

      const div_card = document.createElement('div');
      div_card.innerHTML = `
          <div class="row">
            <div class="column">
              <div class="card" id="${review._id}">
                <p><strong>Review: </strong>${review.review}</p>
                <p><strong>User: </strong>${review.user}</p>
                <p><a href="#"onclick="editReview('${review._id}','${review.review}', '${review.user}')">✏️</a> <a href="#" onclick="deleteReview('${review._id}')">🗑</a></p>
              </div>
            </div>
          </div>
        `
     
      main.appendChild(div_card);})
    });
  }

  function editReview(id, review, user) {

    const element = document.getElementById(id);
    const reviewInputId = "review" + id
    const userInputId = "user" + id
    
    element.innerHTML = `
                <p><strong>Review: </strong>
                  <input type="text" id="${reviewInputId}" value="${review}">
                </p>
                <p><strong>User: </strong>
                  <input type="text" id="${userInputId}" value="${user}">
                </p>
                <p><a href="#" onclick="saveReview('${reviewInputId}', '${userInputId}', '${id}',)">💾</a>
                </p>
    
    `
  }

